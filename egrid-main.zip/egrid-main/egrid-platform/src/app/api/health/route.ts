import { NextResponse } from "next/server";

export function GET() {
  return NextResponse.json({
    status: "ok",
    product: "eGrid Platform",
    architecture: "nextjs-app-router",
    modules: ["core", "people", "fleet", "site", "roles", "billing"]
  });
}
